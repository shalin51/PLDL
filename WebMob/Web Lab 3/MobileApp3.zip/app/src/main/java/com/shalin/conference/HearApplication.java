package com.shalin.conference;

import android.app.Application;

import com.shalin.conference.SharedPrefsUtils;

public class HearApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        SharedPrefsUtils.getInstance(this);
    }
}
